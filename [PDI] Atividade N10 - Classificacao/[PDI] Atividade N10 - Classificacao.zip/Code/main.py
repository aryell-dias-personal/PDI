import matplotlib.image as mpimg
import numpy as np
import classificacao
# import create_data

if __name__ == '__main__':
    classificacao.SVM()
    